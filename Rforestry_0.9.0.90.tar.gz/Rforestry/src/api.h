#include <vector>
#include <string>
#include <iostream>
#include <random>
#include "forestry.h"
#include "utils.h"

#ifndef FORESTRYCPP_API_H
#define FORESTRYCPP_API_H

#endif //FORESTRYCPP_API_H


extern "C" double train_forest(
        int i
);
