library(testthat)
library(Rforestry)

test_check("Rforestry")
